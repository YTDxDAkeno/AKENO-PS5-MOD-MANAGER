This file was installed by the Akeno PS5 Mod Manager test package.
It is never read by the game and can be removed at any time.
