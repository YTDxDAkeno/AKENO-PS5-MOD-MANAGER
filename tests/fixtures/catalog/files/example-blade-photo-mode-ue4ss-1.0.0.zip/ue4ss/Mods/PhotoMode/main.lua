AKENO DEMO PLACEHOLDER - not real game content.
lua script
