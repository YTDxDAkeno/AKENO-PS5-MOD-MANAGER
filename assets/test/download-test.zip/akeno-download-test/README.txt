This harmless file tests downloads in Akeno PS5 Mod Manager.
It contains no code and is deleted again after the test.
